# RTL Reader + Ad Cleaner

## Installation
- Open Chrome Extensions and enable Developer mode.
- Click Load unpacked and select the `chrome-rtl-adblocker` folder.

## Permissions
- `activeTab`: toggle on the current tab.
- `scripting`: inject CSS and scripts.
- `storage`: save user settings.
- `tabs`: detect tab updates for auto-RTL sites.

## Usage
- Click the toolbar icon to open the popup. Toggle RTL and view ads hidden.
- Press `Alt+R` to toggle.
- Add sites in Options to enable RTL automatically.

## Privacy
- Runs locally. No page content is sent externally.

## Troubleshooting
- If the page layout breaks, disable and adjust whitelist selectors in Options.

## Selectors Examples
- Ad patterns: `ad`, `ads`, `sponsor`, `promo`, `adsbygoogle`, `doubleclick`.
- Custom selectors: `.ad-banner`, `#ads`, `[aria-label*="sponsored"]`.

## Acceptance Checks
- Direction toggling preserves DOM order: run in DevTools Console:
```
var before=Array.from(document.body.querySelectorAll('*')).map(n=>n.tagName);
__RTL_EXT.enable();
var after=Array.from(document.body.querySelectorAll('*')).map(n=>n.tagName);
console.log(JSON.stringify(before)===JSON.stringify(after));
```
- Ads hidden count appears in the popup.

## Tests
- Open `tests/run-tests.html` directly and review logs.
- Load sample pages under `tests/pages/` and toggle RTL.

## Short Test Report
- Arabic news page: text flows RTL, code blocks remain LTR, a 300x250 iframe and a `.adbanner` div hidden. DOM order unchanged.
- English page with inline ads: layout remains LTR until toggled, iframe 728x90 and `#ads` hidden, main article preserved.
- Mixed-language web app: elements read RTL when toggled, English segments with `pre` stay LTR, `.adchoices` hidden. Performance stays responsive.

