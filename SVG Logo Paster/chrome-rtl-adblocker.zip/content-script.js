(function(){
  var enabled=false;
  var hidden=[];
  var adsCount=0;
  var observer=null;
  var debounceTimer=null;
  var settings={
    adPatterns:['ad','ads','sponsor','promo','promoted','doubleclick','adsbygoogle','adbanner','advertisement','adchoices'],
    customSelectors:[],
    whitelistSelectors:['main','article','nav','form','header','footer','section','[role="main"]'],
    siteWhitelist:[],
    gentleHide:true
  };
  function readSettings(){
    try{ chrome.storage.local.get(['adPatterns','customSelectors','whitelistSelectors','siteWhitelist','gentleHide'], function(s){
      if(Array.isArray(s.adPatterns)) settings.adPatterns=s.adPatterns;
      if(Array.isArray(s.customSelectors)) settings.customSelectors=s.customSelectors;
      if(Array.isArray(s.whitelistSelectors)) settings.whitelistSelectors=s.whitelistSelectors;
      if(Array.isArray(s.siteWhitelist)) settings.siteWhitelist=s.siteWhitelist;
      if(typeof s.gentleHide==='boolean') settings.gentleHide=s.gentleHide;
    }); }catch(e){}
  }
  function markEnabled(){ document.documentElement.setAttribute('data-rtl-ext','1'); }
  function markDisabled(){ document.documentElement.removeAttribute('data-rtl-ext'); }
  function isWhitelistedSite(){
    try{ var host=location.hostname.toLowerCase(); for(var i=0;i<settings.siteWhitelist.length;i++){ if(host.indexOf(String(settings.siteWhitelist[i]).toLowerCase())!==-1) return true; } }catch(e){}
    return false;
  }
  function hideNode(el){
    if(el.getAttribute('data-rtl-hidden')==='1') return;
    el.setAttribute('data-rtl-hidden','1');
    el.setAttribute('aria-hidden','true');
    var mode=settings.gentleHide? 'visibility' : 'display';
    el.setAttribute('data-hide-mode', mode);
    if(mode==='visibility') el.style.visibility='hidden'; else el.style.display='none';
    adsCount++;
    hidden.push(el);
  }
  function unhideAll(){
    for(var i=0;i<hidden.length;i++){ var el=hidden[i]; if(el && el.getAttribute){ el.removeAttribute('data-rtl-hidden'); el.removeAttribute('aria-hidden'); el.removeAttribute('data-hide-mode'); el.style.display=''; el.style.visibility=''; }}
    hidden=[]; adsCount=0;
  }
  function applyLtrSafeguards(root){
    var sel='pre, code, kbd, samp, .code, .pre, .math, [dir="ltr"]';
    var nodes=root.querySelectorAll(sel);
    for(var i=0;i<nodes.length;i++){ nodes[i].setAttribute('data-rtl-prefer-ltr','1'); }
  }
  function maybeHide(el){
    for(var i=0;i<settings.whitelistSelectors.length;i++){ if(el.matches(settings.whitelistSelectors[i])) return; }
    var patterns=settings.adPatterns;
    if(window.RTLUtils && window.RTLUtils.isAdCandidate(el, patterns)) hideNode(el);
    for(var j=0;j<settings.customSelectors.length;j++){ if(el.matches(settings.customSelectors[j])) hideNode(el); }
  }
  function walkAndProcess(root){
    applyLtrSafeguards(root);
    var list=root.querySelectorAll('*');
    var limit=500;
    var count=0;
    for(var i=0;i<list.length;i++){
      var el=list[i];
      if(count>=limit) break;
      maybeHide(el);
      count++;
    }
  }
  function processMutations(records){
    var addeds=[];
    for(var i=0;i<records.length;i++){
      var r=records[i];
      for(var j=0;j<r.addedNodes.length;j++){ var n=r.addedNodes[j]; if(n.nodeType===1) addeds.push(n); }
    }
    var batchLimit=300;
    var processed=0;
    for(var k=0;k<addeds.length;k++){
      if(processed>=batchLimit) break;
      var n=addeds[k];
      applyLtrSafeguards(n);
      if(n.nodeType===1) maybeHide(n);
      processed++;
    }
  }
  function startObserver(){
    if(observer) return;
    observer=new MutationObserver(function(records){
      if(debounceTimer) clearTimeout(debounceTimer);
      debounceTimer=setTimeout(function(){ processMutations(records); }, 100);
    });
    observer.observe(document.documentElement, { childList:true, subtree:true });
  }
  function stopObserver(){ if(observer){ observer.disconnect(); observer=null; } }
  function enable(){ if(enabled) return; enabled=true; markEnabled(); readSettings(); walkAndProcess(document);
    startObserver();
    chrome.runtime.sendMessage({type:'status', enabled:true, adsHiddenCount:adsCount});
  }
  function disable(){ if(!enabled) return; enabled=false; markDisabled(); stopObserver(); unhideAll(); chrome.runtime.sendMessage({type:'status', enabled:false, adsHiddenCount:adsCount}); }
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse){
    if(msg && msg.type==='toggle'){ if(enabled) disable(); else enable(); sendResponse({enabled:enabled, adsHiddenCount:adsCount}); return; }
    if(msg && msg.type==='enable'){ enable(); sendResponse({enabled:true, adsHiddenCount:adsCount}); return; }
    if(msg && msg.type==='disable'){ disable(); sendResponse({enabled:false, adsHiddenCount:adsCount}); return; }
    if(msg && msg.type==='undo'){ unhideAll(); sendResponse({enabled:enabled, adsHiddenCount:adsCount}); return; }
    if(msg && msg.type==='getStatus'){ sendResponse({enabled:enabled, adsHiddenCount:adsCount}); return; }
  });
  window.__RTL_EXT={ enable:enable, disable:disable, getStatus:function(){ return {enabled:enabled, adsHiddenCount:adsCount}; }, undo:unhideAll };
})();
