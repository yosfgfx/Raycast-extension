#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
zip -r ../chrome-rtl-adblocker.zip . -x "tests/*" -x "icons/*"
echo "Built ../chrome-rtl-adblocker.zip"

