async function activeTab(){ const t=await chrome.tabs.query({active:true, currentWindow:true}); return t&&t[0]; }
async function getStatus(){ const tab=await activeTab(); if(!tab) return {enabled:false, adsHiddenCount:0}; try{ const resp=await chrome.tabs.sendMessage(tab.id, {type:'getStatus'}); return resp||{enabled:false, adsHiddenCount:0}; }catch(e){ return {enabled:false, adsHiddenCount:0}; }}
async function toggle(){ const tab=await activeTab(); if(!tab) return; try{ const s=await chrome.tabs.sendMessage(tab.id, {type:'toggle'}); render(s); }catch(e){ try{ await chrome.scripting.insertCSS({ target:{ tabId:tab.id, allFrames:true }, files:['rtl.css'] }); await chrome.scripting.executeScript({ target:{ tabId:tab.id, allFrames:true }, files:['lib/utils.js','content-script.js'] }); const s2=await chrome.tabs.sendMessage(tab.id, {type:'toggle'}); render(s2); }catch(err){} } }
function render(s){ document.getElementById('status').textContent = s.enabled ? 'Enabled' : 'Disabled'; document.getElementById('ads-count').textContent = String(s.adsHiddenCount||0); document.getElementById('toggle').textContent = s.enabled? 'Disable':'Enable'; }
async function undo(){ const tab=await activeTab(); if(!tab) return; try{ const s=await chrome.tabs.sendMessage(tab.id, {type:'undo'}); render(s); }catch(e){} }
document.getElementById('toggle').addEventListener('click', toggle);
document.getElementById('undo').addEventListener('click', undo);
(async function(){ render(await getStatus()); })();

