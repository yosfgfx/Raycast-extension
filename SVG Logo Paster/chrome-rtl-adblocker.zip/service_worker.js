const tabState=new Map();
function getActiveTab(){ return chrome.tabs.query({active:true, currentWindow:true}).then(t=>t&&t[0]); }
async function ensureInjected(tabId){
  try{
    await chrome.scripting.insertCSS({ target:{ tabId, allFrames:true }, files:['rtl.css'] });
    await chrome.scripting.executeScript({ target:{ tabId, allFrames:true }, files:['lib/utils.js','content-script.js'] });
  }catch(e){}
}
async function enableForTab(tabId){
  await ensureInjected(tabId);
  await chrome.tabs.sendMessage(tabId, { type:'enable' });
  tabState.set(tabId, { enabled:true, adsHiddenCount:0 });
  chrome.action.setBadgeText({ tabId, text:'RTL' });
}
async function disableForTab(tabId){
  try{ await chrome.tabs.sendMessage(tabId, { type:'disable' }); }catch(e){}
  try{ await chrome.scripting.removeCSS({ target:{ tabId, allFrames:true }, files:['rtl.css'] }); }catch(e){}
  tabState.set(tabId, { enabled:false, adsHiddenCount:0 });
  chrome.action.setBadgeText({ tabId, text:'' });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if(msg && msg.type==='status'){ if(sender.tab){ var s=tabState.get(sender.tab.id)||{}; s.enabled=msg.enabled; s.adsHiddenCount=msg.adsHiddenCount||0; tabState.set(sender.tab.id, s); } }
});
chrome.commands.onCommand.addListener(async(command)=>{ if(command==='toggle_rtl'){ const tab=await getActiveTab(); if(!tab) return; const s=tabState.get(tab.id); if(s && s.enabled) await disableForTab(tab.id); else await enableForTab(tab.id); }});
chrome.tabs.onUpdated.addListener(async(tabId, changeInfo, tab)=>{
  if(changeInfo.status!=='complete') return;
  try{
    const cfg=await chrome.storage.local.get(['autoRtlSites']);
    const list=Array.isArray(cfg.autoRtlSites)? cfg.autoRtlSites : [];
    const u=new URL(tab.url||'');
    const host=u.hostname.toLowerCase();
    let should=false;
    for(let i=0;i<list.length;i++){ if(host.indexOf(String(list[i]).toLowerCase())!==-1){ should=true; break; } }
    if(should) await enableForTab(tabId);
  }catch(e){}
});
chrome.action.onClicked.addListener(async(tab)=>{ if(!tab || !tab.id) return; const s=tabState.get(tab.id); if(s && s.enabled) await disableForTab(tab.id); else await enableForTab(tab.id); });

