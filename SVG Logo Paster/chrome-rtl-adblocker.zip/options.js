function readLines(value){ return value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean); }
async function load(){ const s=await chrome.storage.local.get(['autoRtlSites','adPatterns','customSelectors','whitelistSelectors','gentleHide']); document.getElementById('auto-sites').value = (s.autoRtlSites||[]).join('\n'); document.getElementById('ad-patterns').value = (s.adPatterns||['ad','ads','sponsor','promo','promoted','doubleclick','adsbygoogle','adbanner','advertisement','adchoices']).join('\n'); document.getElementById('custom-selectors').value = (s.customSelectors||[]).join('\n'); document.getElementById('whitelist-selectors').value = (s.whitelistSelectors||['main','article','nav','form','header','footer','section','[role="main"]']).join('\n'); document.getElementById('gentle-hide').checked = !!s.gentleHide; }
async function saveAuto(){ const list=readLines(document.getElementById('auto-sites').value); await chrome.storage.local.set({ autoRtlSites:list }); }
async function savePatterns(){ const list=readLines(document.getElementById('ad-patterns').value); await chrome.storage.local.set({ adPatterns:list }); }
async function saveSelectors(){ const list=readLines(document.getElementById('custom-selectors').value); await chrome.storage.local.set({ customSelectors:list }); }
async function saveWhitelist(){ const list=readLines(document.getElementById('whitelist-selectors').value); await chrome.storage.local.set({ whitelistSelectors:list }); }
async function saveBehavior(){ const gh=document.getElementById('gentle-hide').checked; await chrome.storage.local.set({ gentleHide:gh }); }
document.getElementById('save-auto').addEventListener('click', saveAuto);
document.getElementById('save-patterns').addEventListener('click', savePatterns);
document.getElementById('save-selectors').addEventListener('click', saveSelectors);
document.getElementById('save-whitelist').addEventListener('click', saveWhitelist);
document.getElementById('save-behavior').addEventListener('click', saveBehavior);
load();

